/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package npman;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 *
 * @author brc
 */
class homeSummaryPanel extends JPanel {

    public homeSummaryPanel() {
    
        setLayout(new GridBagLayout());
        //setPreferredSize(new Dimension(750,700));
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.ipady = 3;
           
                
        JLabel summaryTitle = new JLabel("Agency Summary");
        c.gridy = 1;
        add(summaryTitle,c);
        
        location a = new location();
        int locCount = a.getCountLoc();
        
        
        JLabel locCountLabel = new JLabel("There are " + locCount + " locations");
        c.gridy = 2;
        add(locCountLabel,c);
        
        employee b = new employee();
        int empCount = b.getCountEmp();
        
        
        JLabel empCountLabel = new JLabel ("There are " + empCount + " employees");
        c.gridy = 3;
        add(empCountLabel,c);
        
        Donor d = new Donor();
        int donorCount = d.getCountDonor();
        
        JLabel donorCountLabel = new JLabel ("There are " + donorCount + " donors");
        c.gridy = 4;
        add(donorCountLabel,c);
        
        donation e = new donation();
        int donationCount = e.getCountDonation();
        
        JLabel donationCountLabel = new JLabel ("There are " + donationCount + " donations");
        c.gridy = 5;
        add(donationCountLabel,c);
        
        double donationSum = e.getSumDonation();
        
        JLabel donationSumLabel = new JLabel ("You have received " + donationSum + " in donations");
        c.gridy = 6;
        add(donationSumLabel,c);
        
    }
    
}
